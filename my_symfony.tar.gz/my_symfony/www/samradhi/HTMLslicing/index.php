<?php
include('header.php');
include('slider.php');
?>
<!-- midcontainer -->
<div class="mid-container"> </div>
<!-- end midcontainer -->

<div class="inner-middle-section">
  <div class="container">
    <div class="row">
      <div class="home-page">
        <div class="top-news-block clearfix">
          <div class="news-heading">News</div>
          <div class="news-deatil-block">
            <div id="donations2">
              <div class="item">
                <div class="donations-detail">
                  <h2>Welcome to EYBOS</h2>
                  <p>Quisque blandit, nisi et posuere egestas, velit dolor elementum tellus, a finibus massa lectus eget risus.</p>
                </div>
              </div>
              <div class="item">
                <div class="donations-detail">
                  <p>Proin fringilla viverra <a href="#">Donate to</a> Nulla vulputate velit</p>
                </div>
              </div>
              <div class="item">
                <div class="donations-detail">
                  <p>Proin fringilla viverra <a href="#">Donate to</a> Nulla vulputate velit</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="form-box special-business">
          <h2>Special Business Promotions</h2>
          <div class="special-business-block">
            <div class="special_block">
              <div class="special-info-block clearfix">
                <div class="col-md-6 col-sm-6 special-business-lf">
                  <div class="special-lf"> <a href="#"><img src="images/s1.jpg" alt="" /></a> </div>
                  <div class="special-rh">
                    <h3><a href="#"><i class="fa fa-institution" aria-hidden="true"></i>Company name <span> Proin mattis vulputate imperdiet</span></a> </h3>
                    <p>Duis elementum, tellus sit amet porttitor sollicitudin, nibh lacus bibendum arcu, quis convallis ipsum neque non sem. Aliquam blandit ipsum eget consectetur vestibulum. </p>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 special-business-rh">
                  <div class="special-block clearfix">
                    <div class="special-lf"> <a href="#"><img src="images/s5.jpg" alt=""></a> </div>
                    <div class="special-rh">
                      <h3><a href="#"><i class="fa fa-institution" aria-hidden="true"></i>Company name <span> Proin mattis vulputate imperdiet</span></a> </h3>
                      <p>Duis elementum, tellus sit amet porttitor sollicitudin, nibh lacus bibendum arcu, quis convallis ipsum neque non sem. Aliquam blandit ipsum eget consectetur vestibulum. </p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="special-info-block clearfix">
                <div class="col-md-6 col-sm-6 special-business-lf">
                  <div class="special-lf"> <a href="#"><img src="images/s1.jpg" alt="" /></a> </div>
                  <div class="special-rh">
                    <h3><a href="#"><i class="fa fa-institution" aria-hidden="true"></i>Company name <span> Proin mattis vulputate imperdiet</span></a> </h3>
                    <p>Duis elementum, tellus sit amet porttitor sollicitudin, nibh lacus bibendum arcu, quis convallis ipsum neque non sem. Aliquam blandit ipsum eget consectetur vestibulum. </p>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 special-business-rh">
                  <div class="special-block clearfix">
                    <div class="special-lf"> <a href="#"><img src="images/s5.jpg" alt=""></a> </div>
                    <div class="special-rh">
                      <h3><a href="#"><i class="fa fa-institution" aria-hidden="true"></i>Company name <span> Proin mattis vulputate imperdiet</span></a> </h3>
                      <p>Duis elementum, tellus sit amet porttitor sollicitudin, nibh lacus bibendum arcu, quis convallis ipsum neque non sem. Aliquam blandit ipsum eget consectetur vestibulum. </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="form-box special-business">
          <h2>Charity Events</h2>
          <div class="special-business-block clearfix">
            <div class="special-info-block clearfix">
              <div class="col-md-6 col-sm-6 special-business-lf">
                <div class="special-lf"> <a href="#"><img src="images/s1.jpg" alt="" /></a> </div>
                <div class="special-rh">
                  <h3><a href="#"><i class="fa fa-institution" aria-hidden="true"></i>Company name <span> Proin mattis vulputate imperdiet</span></a> </h3>
                  <p>Duis elementum, tellus sit amet porttitor sollicitudin, nibh lacus bibendum arcu, quis convallis ipsum neque non sem. Aliquam blandit ipsum eget consectetur vestibulum. </p>
                </div>
              </div>
              <div class="col-md-6 col-sm-6 special-business-rh">
                <div class="special-block clearfix">
                  <div class="special-lf"> <a href="#"><img src="images/s5.jpg" alt=""></a> </div>
                  <div class="special-rh">
                    <h3><a href="#"><i class="fa fa-institution" aria-hidden="true"></i>Company name <span> Proin mattis vulputate imperdiet</span></a> </h3>
                    <p>Duis elementum, tellus sit amet porttitor sollicitudin, nibh lacus bibendum arcu, quis convallis ipsum neque non sem. Aliquam blandit ipsum eget consectetur vestibulum. </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="special-info-block clearfix">
              <div class="col-md-6 col-sm-6 special-business-lf">
                <div class="special-lf"> <a href="#"><img src="images/s1.jpg" alt="" /></a> </div>
                <div class="special-rh">
                  <h3><a href="#"><i class="fa fa-institution" aria-hidden="true"></i>Company name <span> Proin mattis vulputate imperdiet</span></a> </h3>
                  <p>Duis elementum, tellus sit amet porttitor sollicitudin, nibh lacus bibendum arcu, quis convallis ipsum neque non sem. Aliquam blandit ipsum eget consectetur vestibulum. </p>
                </div>
              </div>
              <div class="col-md-6 col-sm-6 special-business-rh">
                <div class="special-block clearfix">
                  <div class="special-lf"> <a href="#"><img src="images/s5.jpg" alt=""></a> </div>
                  <div class="special-rh">
                    <h3><a href="#"><i class="fa fa-institution" aria-hidden="true"></i>Company name <span> Proin mattis vulputate imperdiet</span></a> </h3>
                    <p>Duis elementum, tellus sit amet porttitor sollicitudin, nibh lacus bibendum arcu, quis convallis ipsum neque non sem. Aliquam blandit ipsum eget consectetur vestibulum. </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="partnership-section">
  <div class="container">
    <div class="row">
      <div class="partnership-head">
        <h2>EYBOS partnership</h2>
        <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, <span>omnis voluptas assumenda est, omnis dolor repellendus</span></p>
      </div>
      <div class="col-md-4 services-box"> <a href="#"><img src="images/icon1.png" alt="" /></a>
        <h3>Discount offering to members</h3>
        <p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam.</p>
      </div>
      <div class="col-md-4 services-box"> <a href="#"><img src="images/icon2.png" alt="" /></a>
        <h3>Discount offering to members</h3>
        <p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam.</p>
      </div>
      <div class="col-md-4 services-box"> <a href="#"><img src="images/icon3.png" alt="" /></a>
        <h3>Discount offering to members</h3>
        <p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam.</p>
      </div>
    </div>
  </div>
</div>
<?php
include('footer.php');
?>