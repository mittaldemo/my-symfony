<div class="donations-section clearfix">
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-sm-4 donations-left no-padding">
        <div class="donate-charity"> <span class="price">&#36;</span>
          <div class="charity-block">
            <ul class="charity-info">
              <li>5</li>
              <li>2</li>
            </ul>
            <ul class="charity-info info-two">
              <li>0</li>
              <li>0</li>
              <li>0</li>
            </ul>
            <ul class="charity-info info-three">
              <li>0</li>
              <li>0</li>
              <li>0</li>
            </ul>
            <p>Donate to charity through Charity Choice </p>
          </div>
        </div>
      </div>
      <div class="col-md-8 col-sm-8 donations-right rh-padding">
        <div class="donations-top-lf">
          <div class="donations-heding">
            <h2>Top 5 Donations<span>this week</span></h2>
          </div>
        </div>
        <div class="donations-top-rh">
          <div id="donations">
            <div class="item">
              <div class="donations-detail">
                <p>Proin fringilla viverra <a href="#">Donate to</a> Nulla vulputate velit</p>
              </div>
            </div>
            <div class="item">
              <div class="donations-detail">
                <p>Proin fringilla viverra <a href="#">Donate to</a> Nulla vulputate velit</p>
              </div>
            </div>
            <div class="item">
              <div class="donations-detail">
                <p>Proin fringilla viverra <a href="#">Donate to</a> Nulla vulputate velit</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
</div>
<!--end slider--> 
