<?php
include('../connection.php');
?>
<html>
<head>
	<title></title>
	       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
            <script src="js/jquery.js"></script>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
            <script src="vendor/jquery-validation/dist/jquery.validate.min.js"></script>
            <link rel="stylesheet" href="admincss.css">
</head>
<body>

<div class="row adminmenu">
<ul>
	<li><a href="logo.php">Logo</a></li>
	<li><a href="menu.php">Menu</a></li>
	<li><a href="subMenu.php">Sub Menu</a></li>
	<li><a href="slider.php">Slider</a></li>
	<li><a href="heading.php">Heading</a></li>
	<li><a href="product.php">Product</a></li>
	<li><a href="footer1.php">Footer1</a></li>
	<li><a href="footer2.php">Footer2</a></li>
	<li><a href="footer3.php">Footer3</a></li>
	<li><a href="order.php">Order Details</a></li>
	<li><a href="shipping.php">Shipping Details</a></li>
</ul>
</div>
</body>
</html>