<html>
<head>
</head>
<body>

	<input type="text" placeholder="search">
    
    <button type="submit" class="btn icon-fallback-text header-bar__search-submit">
      <span class="icon icon-search" aria-hidden="true"></span>
      <span class="fallback-text">Search</span>
    </button>


</body>
</html>