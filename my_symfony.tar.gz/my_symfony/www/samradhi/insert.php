<?php

echo "record inserted";




?>