<html>
	<head>
	<script type="text/javascript">
	function display()
	{
		try
		{
		var a=10;
		document.getElementById('demo').innerHTML=a;
	    }
		
		
	}
	</script>	
	</head>
	<body>
	<p id="demo"></p>
	<input type="button" name="" value="try it" onclick="return display();">	
	</body>
</html>