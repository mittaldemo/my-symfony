<?php

$conn=mysqli_connect('localhost','root','root','samradhi');

if(!$conn)
{
	$conn->mysqli_connect_error;
	die;
}


?>