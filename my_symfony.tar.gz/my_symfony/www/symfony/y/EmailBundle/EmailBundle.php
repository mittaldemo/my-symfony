<?php

namespace EmailBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EmailBundle extends Bundle
{
}
